/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.sql.*;
import Buku.*;
/**
 *
 * @author aysla
 */
public class SQL {
    static final String JDBC_DRIVER="com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/borrowbook";
    static final String USER="root"; //USERNAME
    static final String PSW = ""; // PASSWORD
    static String stmt;
    //Deklarasi variabel yang kelola database
    static Connection con;
    static Statement stat;
    static ResultSet rst;
    
    public static Connection connect() throws Exception{
        Class.forName(JDBC_DRIVER);
        return DriverManager.getConnection(DB_URL, USER, PSW);
    }
    
    public static int cekUser(String username, String password) throws Exception{
        con = connect();
        stat = con.createStatement();
        stmt = "SELECT COUNT(*) FROM USERS WHERE USERNAME = '"+username+"' and PASSWORD = '"+password+"'";
        rst = stat.executeQuery(stmt);
        rst.next();
        int r = rst.getInt(1);
        stat.close();
        con.close();
        return r;
    }
    
    public static String showid(String user) throws Exception{
        con = connect();
        stat = con.createStatement();
        stmt = "SELECT FROM USERS WHERE USERNAME = '"+user+"'";
        String r = "";
        stat.close();
        con.close();
        return r;
    }
    
    public static int cekpinjam(String user) throws Exception{
        con = connect();
        stat = con.createStatement();
        stmt = "SELECT COUNT(*) FROM data_pinjam WHERE username = '" + user +"'";
        rst = stat.executeQuery(stmt);
        rst.next();
        int r = rst.getInt(1);
        stat.close();
        con.close();
        return r;
    }
    
    public static int cekkembali(String user) throws Exception{
        con = connect();
        stat = con.createStatement();
        stmt = "SELECT COUNT(*) FROM data_kembali WHERE username = '" + user +"'";
        rst = stat.executeQuery(stmt);
        rst.next();
        int r = rst.getInt(1);
        stat.close();
        con.close();
        return r;
    }
    
    public static int showbook(String kode, String judul) throws Exception{
        con = connect();
        stat = con.createStatement();
        int kd = Integer.parseInt(kode);
        stmt = "SELECT COUNT(*) FROM data_buku WHERE id_buku = " + kd 
                + " and nama_buku = '"+judul+"'";
        rst = stat.executeQuery(stmt);
        rst.next();
        int r = rst.getInt(1);
        stat.close();
        con.close();
        return r;
    }
    
    public static void InsertPinjam(Data_Pinjam p) throws Exception{
        con = connect();
        stat = con.createStatement();
        String dt = p.getTgl();
        Date date = Date.valueOf(dt);
        stmt = "insert into data_pinjam (username, kategori, kode_buku, judul_buku, tgl, durasi) values('"+
                p.getUsername()+"', '"
                + p.getKategori()+"', '"
                + p.getKode_buku()+"', '"
                +p.getJudul_buku()+"', '"
                +date + "', '"
                +p.getDurasi() + "')";
        stat.executeUpdate(stmt);
        stat.close();
        con.close();
    }
    
    public static void InsertKembali(Data_Kembali p) throws Exception{
        con = connect();
        stat = con.createStatement();
        String dt = p.getTgl();
        Date date = Date.valueOf(dt);
        stmt = "insert into data_kembali (username, kategori, kode_buku, judul_buku, tanggal_kembali) values('"+
                p.getUsername()+"', '"
                + p.getKategori()+"', '"
                + p.getKode_buku()+"', '"
                +p.getJudul_buku()+"', '"
                +date + "')";
        stat.executeUpdate(stmt);
        stat.close();
        con.close();
    }
    
    public static void registrasi(String username, String password, String nama, String id_card, String email, String no_hp, String member) throws Exception{
        con = connect();
        stat = con.createStatement();
        stmt = "Insert into users(username, password, nama, id_card, email, no_hp, jenis_anggota) values ('"+username+"', '"
                +password +"', '"
                +nama+"', '"
                +id_card+"', '"
                +email+"', '"
                +no_hp+"', '"
                +member+"')";
        stat.executeUpdate(stmt);
        stat.close();
        con.close();
    }
    
    public static int cekPeg(String username) throws Exception{
        con = connect();
        stat = con.createStatement();
        stmt = "SELECT COUNT(*) FROM USERS WHERE USERNAME = '"+username+"' and "
                + "(jenis_anggota = 'Manager' or jenis_anggota = 'Petugas')";
        rst = stat.executeQuery(stmt);
        rst.next();
        int r = rst.getInt(1);
        stat.close();
        con.close();
        return r;
    }
    
}
