/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Menu;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author ACER
 */
@Entity
@Table(name = "data_buku", catalog = "borrowbook", schema = "")
@NamedQueries({
    @NamedQuery(name = "DataBuku.findAll", query = "SELECT d FROM DataBuku d")
    , @NamedQuery(name = "DataBuku.findByIdBuku", query = "SELECT d FROM DataBuku d WHERE d.idBuku = :idBuku")
    , @NamedQuery(name = "DataBuku.findByNamaBuku", query = "SELECT d FROM DataBuku d WHERE d.namaBuku = :namaBuku")
    , @NamedQuery(name = "DataBuku.findByKategori", query = "SELECT d FROM DataBuku d WHERE d.kategori = :kategori")
    , @NamedQuery(name = "DataBuku.findByPengarang", query = "SELECT d FROM DataBuku d WHERE d.pengarang = :pengarang")
    , @NamedQuery(name = "DataBuku.findByTahun", query = "SELECT d FROM DataBuku d WHERE d.tahun = :tahun")})
public class DataBuku implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id_buku")
    private Integer idBuku;
    @Basic(optional = false)
    @Column(name = "nama_buku")
    private String namaBuku;
    @Basic(optional = false)
    @Column(name = "kategori")
    private String kategori;
    @Basic(optional = false)
    @Column(name = "pengarang")
    private String pengarang;
    @Basic(optional = false)
    @Column(name = "tahun")
    private String tahun;

    public DataBuku() {
    }

    public DataBuku(Integer idBuku) {
        this.idBuku = idBuku;
    }

    public DataBuku(Integer idBuku, String namaBuku, String kategori, String pengarang, String tahun) {
        this.idBuku = idBuku;
        this.namaBuku = namaBuku;
        this.kategori = kategori;
        this.pengarang = pengarang;
        this.tahun = tahun;
    }

    public Integer getIdBuku() {
        return idBuku;
    }

    public void setIdBuku(Integer idBuku) {
        Integer oldIdBuku = this.idBuku;
        this.idBuku = idBuku;
        changeSupport.firePropertyChange("idBuku", oldIdBuku, idBuku);
    }

    public String getNamaBuku() {
        return namaBuku;
    }

    public void setNamaBuku(String namaBuku) {
        String oldNamaBuku = this.namaBuku;
        this.namaBuku = namaBuku;
        changeSupport.firePropertyChange("namaBuku", oldNamaBuku, namaBuku);
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        String oldKategori = this.kategori;
        this.kategori = kategori;
        changeSupport.firePropertyChange("kategori", oldKategori, kategori);
    }

    public String getPengarang() {
        return pengarang;
    }

    public void setPengarang(String pengarang) {
        String oldPengarang = this.pengarang;
        this.pengarang = pengarang;
        changeSupport.firePropertyChange("pengarang", oldPengarang, pengarang);
    }

    public String getTahun() {
        return tahun;
    }

    public void setTahun(String tahun) {
        String oldTahun = this.tahun;
        this.tahun = tahun;
        changeSupport.firePropertyChange("tahun", oldTahun, tahun);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idBuku != null ? idBuku.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DataBuku)) {
            return false;
        }
        DataBuku other = (DataBuku) object;
        if ((this.idBuku == null && other.idBuku != null) || (this.idBuku != null && !this.idBuku.equals(other.idBuku))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "GUI.Menu.DataBuku[ idBuku=" + idBuku + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
