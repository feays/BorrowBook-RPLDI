/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Menu;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author ACER
 */
@Entity
@Table(name = "data_kembali", catalog = "borrowbook", schema = "")
@NamedQueries({
    @NamedQuery(name = "DataKembali.findAll", query = "SELECT d FROM DataKembali d")
    , @NamedQuery(name = "DataKembali.findByIdKembali", query = "SELECT d FROM DataKembali d WHERE d.idKembali = :idKembali")
    , @NamedQuery(name = "DataKembali.findByUsername", query = "SELECT d FROM DataKembali d WHERE d.username = :username")
    , @NamedQuery(name = "DataKembali.findByKategori", query = "SELECT d FROM DataKembali d WHERE d.kategori = :kategori")
    , @NamedQuery(name = "DataKembali.findByKodeBuku", query = "SELECT d FROM DataKembali d WHERE d.kodeBuku = :kodeBuku")
    , @NamedQuery(name = "DataKembali.findByJudulBuku", query = "SELECT d FROM DataKembali d WHERE d.judulBuku = :judulBuku")
    , @NamedQuery(name = "DataKembali.findByTanggalKembali", query = "SELECT d FROM DataKembali d WHERE d.tanggalKembali = :tanggalKembali")})
public class DataKembali implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_kembali")
    private Integer idKembali;
    @Basic(optional = false)
    @Column(name = "username")
    private String username;
    @Basic(optional = false)
    @Column(name = "kategori")
    private String kategori;
    @Basic(optional = false)
    @Column(name = "kode_buku")
    private int kodeBuku;
    @Basic(optional = false)
    @Column(name = "judul_buku")
    private String judulBuku;
    @Basic(optional = false)
    @Column(name = "tanggal_kembali")
    @Temporal(TemporalType.DATE)
    private Date tanggalKembali;

    public DataKembali() {
    }

    public DataKembali(Integer idKembali) {
        this.idKembali = idKembali;
    }

    public DataKembali(Integer idKembali, String username, String kategori, int kodeBuku, String judulBuku, Date tanggalKembali) {
        this.idKembali = idKembali;
        this.username = username;
        this.kategori = kategori;
        this.kodeBuku = kodeBuku;
        this.judulBuku = judulBuku;
        this.tanggalKembali = tanggalKembali;
    }

    public Integer getIdKembali() {
        return idKembali;
    }

    public void setIdKembali(Integer idKembali) {
        Integer oldIdKembali = this.idKembali;
        this.idKembali = idKembali;
        changeSupport.firePropertyChange("idKembali", oldIdKembali, idKembali);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        String oldUsername = this.username;
        this.username = username;
        changeSupport.firePropertyChange("username", oldUsername, username);
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        String oldKategori = this.kategori;
        this.kategori = kategori;
        changeSupport.firePropertyChange("kategori", oldKategori, kategori);
    }

    public int getKodeBuku() {
        return kodeBuku;
    }

    public void setKodeBuku(int kodeBuku) {
        int oldKodeBuku = this.kodeBuku;
        this.kodeBuku = kodeBuku;
        changeSupport.firePropertyChange("kodeBuku", oldKodeBuku, kodeBuku);
    }

    public String getJudulBuku() {
        return judulBuku;
    }

    public void setJudulBuku(String judulBuku) {
        String oldJudulBuku = this.judulBuku;
        this.judulBuku = judulBuku;
        changeSupport.firePropertyChange("judulBuku", oldJudulBuku, judulBuku);
    }

    public Date getTanggalKembali() {
        return tanggalKembali;
    }

    public void setTanggalKembali(Date tanggalKembali) {
        Date oldTanggalKembali = this.tanggalKembali;
        this.tanggalKembali = tanggalKembali;
        changeSupport.firePropertyChange("tanggalKembali", oldTanggalKembali, tanggalKembali);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idKembali != null ? idKembali.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DataKembali)) {
            return false;
        }
        DataKembali other = (DataKembali) object;
        if ((this.idKembali == null && other.idKembali != null) || (this.idKembali != null && !this.idKembali.equals(other.idKembali))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "GUI.Menu.DataKembali[ idKembali=" + idKembali + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
