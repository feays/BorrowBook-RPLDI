/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Buku;

/**
 *
 * @author aysla
 */
public class Data_Buku {
    private int id_buku;
    private String nama_buku, kategori, pengarang, tahun;

    public Data_Buku(int id_buku, String nama_buku, String kategori, String pengarang, String tahun) {
        this.id_buku = id_buku;
        this.nama_buku = nama_buku;
        this.kategori = kategori;
        this.pengarang = pengarang;
        this.tahun = tahun;
    }

    public int getId_buku() {
        return id_buku;
    }

    public void setId_buku(int id_buku) {
        this.id_buku = id_buku;
    }

    public String getNama_buku() {
        return nama_buku;
    }

    public void setNama_buku(String nama_buku) {
        this.nama_buku = nama_buku;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getPengarang() {
        return pengarang;
    }

    public void setPengarang(String pengarang) {
        this.pengarang = pengarang;
    }

    public String getTahun() {
        return tahun;
    }

    public void setTahun(String tahun) {
        this.tahun = tahun;
    }  
}
