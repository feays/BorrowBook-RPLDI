/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Buku;

import java.util.Date;
import java.sql.*;

/**
 *
 * @author aysla
 */
public class Data_Kembali{
    private String username;
    private String kategori;
    private int kode_buku;
    private String judul_buku;
    private String tgl;

    public Data_Kembali(String username, String kategori, int kode_buku, String judul_buku, String tgl) {
        this.username = username;
        this.kategori = kategori;
        this.kode_buku = kode_buku;
        this.judul_buku = judul_buku;
        this.tgl = tgl;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public int getKode_buku() {
        return kode_buku;
    }

    public void setKode_buku(int kode_buku) {
        this.kode_buku = kode_buku;
    }

    public String getJudul_buku() {
        return judul_buku;
    }

    public void setJudul_buku(String judul_buku) {
        this.judul_buku = judul_buku;
    }

    public String getTgl() {
        return tgl;
    }

    public void setTgl(String tgl) {
        this.tgl = tgl;
    }
    
    

}